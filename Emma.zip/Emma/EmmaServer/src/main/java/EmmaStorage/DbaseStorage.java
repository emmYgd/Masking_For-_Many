package EmmaStorage;

public class DbaseStorage {
}
