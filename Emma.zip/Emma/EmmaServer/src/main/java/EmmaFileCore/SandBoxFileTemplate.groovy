package EmmaFileCore

import java.security.CryptoPrimitive

trait SandBoxFileTemplate extends ServerFileLoad {


    //create an output file inside the /emma directory:

    //Create an intended file format template(.emma files) inside the new directory

    //get the name of a chosen server file:

    def createEmmaFilesFormat(String FileNameWithExt){
        def strip = stripOldExtensionFormatAway(FileNameWithExt)
        def newFormat = AttachEmmaFormat(strip)

        return newFormat
    }

    def createEmmaDir(){
        //Create a fresh directory for .emma files in the current directory:
        String dirName = "/emma"
        File emmaDir = new File(dirName)
        if(emmaDir.mkdir()){
            return emmaDir
        }
    }

    def stripOldExtensionFormatAway= { String FileWithExt ->
        //strip the previous extension format away:
        String strippedName = FileWithExt.take(FileWithExt.lastIndexOf("."))

        return strippedName
    }

    /*def AttachEmmaFormat = { String  strippedName ->
        def newFileName = strippedName + ".emma"
        newFileName
    }*/
}